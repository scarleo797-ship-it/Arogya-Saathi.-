import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'package:url_launcher/url_launcher.dart';

final FlutterLocalNotificationsPlugin notifications =
    FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tzdata.initializeTimeZones();
  // The device's local time zone is used by the reminder scheduler.
  tz.setLocalLocation(tz.getLocation('Asia/Kolkata'));
  const android = AndroidInitializationSettings('@mipmap/ic_launcher');
  const settings = InitializationSettings(android: android);
  await notifications.initialize(settings);
  runApp(const ArogyaSaathiApp());
}

class Medicine {
  Medicine({
    required this.id,
    required this.name,
    required this.hour,
    required this.minute,
  });

  final int id;
  final String name;
  final int hour;
  final int minute;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'hour': hour,
        'minute': minute,
      };

  factory Medicine.fromJson(Map<String, dynamic> json) => Medicine(
        id: json['id'] as int,
        name: json['name'] as String,
        hour: json['hour'] as int,
        minute: json['minute'] as int,
      );
}

class ArogyaSaathiApp extends StatefulWidget {
  const ArogyaSaathiApp({super.key});

  @override
  State<ArogyaSaathiApp> createState() => _ArogyaSaathiAppState();
}

class _ArogyaSaathiAppState extends State<ArogyaSaathiApp> {
  String language = 'en';
  bool voiceReminders = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      language = prefs.getString('language') ?? 'en';
      voiceReminders = prefs.getBool('voiceReminders') ?? false;
    });
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', language);
    await prefs.setBool('voiceReminders', voiceReminders);
  }

  String tr(String key) => translations[language]?[key] ??
      translations['en']![key] ??
      key;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Arogya Saathi',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B55)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7FAF8),
        textTheme: const TextTheme(
          bodyLarge: TextStyle(fontSize: 18),
          bodyMedium: TextStyle(fontSize: 16),
        ),
      ),
      home: HomeScreen(
        language: language,
        voiceReminders: voiceReminders,
        tr: tr,
        onLanguageChanged: (value) async {
          setState(() => language = value);
          await _saveSettings();
        },
        onVoiceChanged: (value) async {
          setState(() => voiceReminders = value);
          await _saveSettings();
        },
      ),
    );
  }
}

const Map<String, Map<String, String>> translations = {
  'en': {
    'greeting': 'Hello! How can we help?',
    'medicines': 'My medicines',
    'reminders': 'Medicine reminders',
    'sos': 'Emergency SOS',
    'scan': 'Scan medicine barcode',
    'settings': 'Settings',
    'add': 'Add medicine',
    'empty': 'No medicines added yet.',
    'name': 'Medicine name',
    'time': 'Reminder time',
    'save': 'Save',
    'cancel': 'Cancel',
    'taken': 'Taken',
    'delete': 'Delete',
    'voice': 'Speak reminders aloud',
    'language': 'App language',
    'contact': 'Emergency contact phone number',
    'saveContact': 'Save contact',
    'tripleTap': 'Tap the SOS button 3 times to start an emergency message.',
    'noContact': 'Add an emergency contact in Settings first.',
    'smsUnavailable': 'Could not open the SMS app on this device.',
    'barcodeTitle': 'Medicine barcode scanner',
    'barcodeHelp': 'Scan a package barcode. A barcode is only an identifier; medicine details need a verified database.',
    'barcodeRead': 'Barcode read',
    'lookupMissing': 'Online medicine lookup is not connected in this prototype.',
    'permissionNote': 'Allow notifications when Android asks, so reminders can appear.',
  },
  'hi': {
    'greeting': 'नमस्ते! हम आपकी कैसे मदद करें?',
    'medicines': 'मेरी दवाइयाँ',
    'reminders': 'दवा की याद दिलाएँ',
    'sos': 'आपातकालीन SOS',
    'scan': 'दवा का बारकोड स्कैन करें',
    'settings': 'सेटिंग्स',
    'add': 'दवा जोड़ें',
    'empty': 'अभी कोई दवा नहीं जोड़ी गई है।',
    'name': 'दवा का नाम',
    'time': 'याद दिलाने का समय',
    'save': 'सेव करें',
    'cancel': 'रद्द करें',
    'taken': 'ले ली',
    'delete': 'हटाएँ',
    'voice': 'दवा की याद आवाज़ में सुनाएँ',
    'language': 'ऐप की भाषा',
    'contact': 'आपातकालीन संपर्क का फोन नंबर',
    'saveContact': 'संपर्क सेव करें',
    'tripleTap': 'आपातकालीन संदेश शुरू करने के लिए SOS बटन 3 बार दबाएँ।',
    'noContact': 'पहले सेटिंग्स में आपातकालीन संपर्क जोड़ें।',
    'smsUnavailable': 'इस डिवाइस पर SMS ऐप नहीं खुल सका।',
    'barcodeTitle': 'दवा बारकोड स्कैनर',
    'barcodeHelp': 'पैकेट का बारकोड स्कैन करें। बारकोड केवल पहचान संख्या है; दवा की जानकारी के लिए सत्यापित डेटाबेस चाहिए।',
    'barcodeRead': 'बारकोड पढ़ लिया गया',
    'lookupMissing': 'इस प्रोटोटाइप में ऑनलाइन दवा खोज अभी जुड़ी नहीं है।',
    'permissionNote': 'रिमाइंडर पाने के लिए Android पूछे तो नोटिफिकेशन की अनुमति दें।',
  },
  'mr': {
    'greeting': 'नमस्कार! आम्ही तुमची कशी मदत करू?',
    'medicines': 'माझी औषधे',
    'reminders': 'औषधांची आठवण',
    'sos': 'आपत्कालीन SOS',
    'scan': 'औषधाचा बारकोड स्कॅन करा',
    'settings': 'सेटिंग्ज',
    'add': 'औषध जोडा',
    'empty': 'अजून कोणतेही औषध जोडलेले नाही.',
    'name': 'औषधाचे नाव',
    'time': 'आठवणीची वेळ',
    'save': 'जतन करा',
    'cancel': 'रद्द करा',
    'taken': 'घेतले',
    'delete': 'काढून टाका',
    'voice': 'औषधाची आठवण आवाजात सांगा',
    'language': 'अॅपची भाषा',
    'contact': 'आपत्कालीन संपर्काचा फोन नंबर',
    'saveContact': 'संपर्क जतन करा',
    'tripleTap': 'आपत्कालीन संदेश सुरू करण्यासाठी SOS बटण ३ वेळा दाबा.',
    'noContact': 'आधी सेटिंग्जमध्ये आपत्कालीन संपर्क जोडा.',
    'smsUnavailable': 'या डिव्हाइसवर SMS अॅप उघडता आले नाही.',
    'barcodeTitle': 'औषध बारकोड स्कॅनर',
    'barcodeHelp': 'पॅकेटवरील बारकोड स्कॅन करा. बारकोड ही फक्त ओळख संख्या आहे; औषधाची माहिती मिळवण्यासाठी विश्वसनीय डेटाबेस आवश्यक आहे.',
    'barcodeRead': 'बारकोड वाचला',
    'lookupMissing': 'या प्रोटोटाइपमध्ये ऑनलाइन औषध शोध जोडलेला नाही.',
    'permissionNote': 'आठवणी दिसण्यासाठी Android ने विचारल्यास सूचना परवानगी द्या.',
  },
};

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.language,
    required this.voiceReminders,
    required this.tr,
    required this.onLanguageChanged,
    required this.onVoiceChanged,
  });

  final String language;
  final bool voiceReminders;
  final String Function(String) tr;
  final ValueChanged<String> onLanguageChanged;
  final ValueChanged<bool> onVoiceChanged;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Medicine> medicines = [];
  String emergencyPhone = '';
  int sosTapCount = 0;
  DateTime? lastSosTap;
  final FlutterTts tts = FlutterTts();

  @override
  void initState() {
    super.initState();
    _loadData();
    _requestNotificationPermission();
  }

  Future<void> _requestNotificationPermission() async {
    final android = notifications.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await android?.requestNotificationsPermission();
  }

  String tr(String key) => widget.tr(key);

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('medicines') ?? '[]';
    final list = (jsonDecode(raw) as List)
        .map((item) => Medicine.fromJson(Map<String, dynamic>.from(item)))
        .toList();
    if (!mounted) return;
    setState(() {
      medicines = list;
      emergencyPhone = prefs.getString('emergencyPhone') ?? '';
    });
  }

  Future<void> _saveMedicines() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'medicines',
      jsonEncode(medicines.map((medicine) => medicine.toJson()).toList()),
    );
  }

  Future<void> _scheduleMedicine(Medicine medicine) async {
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      medicine.hour,
      medicine.minute,
    );
    if (!scheduled.isAfter(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }
    final langCode = widget.language;
    final body = {
      'en': "It's time to take ${medicine.name}.",
      'hi': 'दवा लेने का समय हो गया है: ${medicine.name}',
      'mr': 'औषध घेण्याची वेळ झाली आहे: ${medicine.name}',
    }[langCode]!;
    await notifications.zonedSchedule(
      medicine.id,
      'Arogya Saathi • ${tr('reminders')}',
      body,
      scheduled,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'medicine_reminders',
          'Medicine reminders',
          channelDescription: 'Scheduled reminders for medicines',
          importance: Importance.max,
          priority: Priority.high,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  Future<void> _addMedicine() async {
    final nameController = TextEditingController();
    TimeOfDay chosenTime = TimeOfDay.now();
    final result = await showDialog<Medicine>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(tr('add')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                autofocus: true,
                decoration: InputDecoration(labelText: tr('name')),
              ),
              const SizedBox(height: 16),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(tr('time')),
                subtitle: Text(chosenTime.format(context)),
                trailing: const Icon(Icons.access_time),
                onTap: () async {
                  final picked = await showTimePicker(
                    context: context,
                    initialTime: chosenTime,
                  );
                  if (picked != null) {
                    setDialogState(() => chosenTime = picked);
                  }
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text(tr('cancel')),
            ),
            FilledButton(
              onPressed: () {
                final name = nameController.text.trim();
                if (name.isEmpty) return;
                Navigator.pop(
                  dialogContext,
                  Medicine(
                    id: DateTime.now().millisecondsSinceEpoch.remainder(1 << 31),
                    name: name,
                    hour: chosenTime.hour,
                    minute: chosenTime.minute,
                  ),
                );
              },
              child: Text(tr('save')),
            ),
          ],
        ),
      ),
    );

    if (result == null) return;
    setState(() => medicines.add(result));
    await _saveMedicines();
    await _scheduleMedicine(result);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(tr('permissionNote'))),
    );
  }

  Future<void> _deleteMedicine(Medicine medicine) async {
    await notifications.cancel(medicine.id);
    setState(() => medicines.removeWhere((item) => item.id == medicine.id));
    await _saveMedicines();
  }

  Future<void> _markTaken(Medicine medicine) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'taken_${medicine.id}_${DateTime.now().year}_${DateTime.now().month}_${DateTime.now().day}';
    await prefs.setBool(key, true);
    if (widget.voiceReminders) {
      final locale = {'en': 'en-US', 'hi': 'hi-IN', 'mr': 'mr-IN'}[widget.language]!;
      await tts.setLanguage(locale);
      await tts.speak('${tr('taken')}: ${medicine.name}');
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${medicine.name}: ${tr('taken')}')),
    );
  }

  Future<void> _openSettings() async {
    final phoneController = TextEditingController(text: emergencyPhone);
    String selectedLanguage = widget.language;
    bool voice = widget.voiceReminders;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(tr('settings')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: selectedLanguage,
                  decoration: InputDecoration(labelText: tr('language')),
                  items: const [
                    DropdownMenuItem(value: 'mr', child: Text('मराठी')),
                    DropdownMenuItem(value: 'hi', child: Text('हिन्दी')),
                    DropdownMenuItem(value: 'en', child: Text('English')),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setDialogState(() => selectedLanguage = value);
                    }
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(tr('voice')),
                  value: voice,
                  onChanged: (value) => setDialogState(() => voice = value),
                ),
                TextField(
                  controller: phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(labelText: tr('contact')),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text(tr('cancel')),
            ),
            FilledButton(
              onPressed: () async {
                widget.onLanguageChanged(selectedLanguage);
                widget.onVoiceChanged(voice);
                final prefs = await SharedPreferences.getInstance();
                await prefs.setString('emergencyPhone', phoneController.text.trim());
                if (mounted) {
                  setState(() => emergencyPhone = phoneController.text.trim());
                }
                if (dialogContext.mounted) Navigator.pop(dialogContext);
              },
              child: Text(tr('save')),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _triggerSos() async {
    if (emergencyPhone.trim().isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(tr('noContact'))),
      );
      await _openSettings();
      return;
    }
    final message = {
      'en': 'EMERGENCY ALERT from Arogya Saathi. Please contact me immediately.',
      'hi': 'Arogya Saathi से आपातकालीन संदेश। कृपया मुझसे तुरंत संपर्क करें।',
      'mr': 'Arogya Saathi कडून आपत्कालीन संदेश. कृपया माझ्याशी त्वरित संपर्क साधा.',
    }[widget.language]!;
    final uri = Uri(
      scheme: 'sms',
      path: emergencyPhone.trim(),
      queryParameters: {'body': message},
    );
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(tr('smsUnavailable'))),
      );
    }
  }

  void _onSosTap() {
    final now = DateTime.now();
    if (lastSosTap == null ||
        now.difference(lastSosTap!) > const Duration(seconds: 3)) {
      sosTapCount = 0;
    }
    lastSosTap = now;
    sosTapCount++;
    if (sosTapCount >= 3) {
      sosTapCount = 0;
      _triggerSos();
    } else {
      setState(() {});
    }
  }

  Future<void> _openScanner() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ScannerScreen(tr: tr),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Arogya Saathi'),
        actions: [
          IconButton(
            tooltip: tr('settings'),
            onPressed: _openSettings,
            icon: const Icon(Icons.settings, size: 30),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(
              tr('greeting'),
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(72),
                textStyle: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
              ),
              onPressed: _addMedicine,
              icon: const Icon(Icons.medication, size: 30),
              label: Text(tr('add')),
            ),
            const SizedBox(height: 8),
            Text(tr('reminders'), style: Theme.of(context).textTheme.titleLarge),
            if (medicines.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Text(tr('empty')),
              ),
            ...medicines.map(
              (medicine) => Card(
                child: ListTile(
                  leading: const Icon(Icons.medication_outlined, size: 34),
                  title: Text(
                    medicine.name,
                    style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w600),
                  ),
                  subtitle: Text(
                    TimeOfDay(hour: medicine.hour, minute: medicine.minute)
                        .format(context),
                  ),
                  trailing: PopupMenuButton<String>(
                    onSelected: (value) {
                      if (value == 'taken') _markTaken(medicine);
                      if (value == 'delete') _deleteMedicine(medicine);
                    },
                    itemBuilder: (_) => [
                      PopupMenuItem(value: 'taken', child: Text(tr('taken'))),
                      PopupMenuItem(value: 'delete', child: Text(tr('delete'))),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 18),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(66),
                textStyle: const TextStyle(fontSize: 19),
              ),
              onPressed: _openSettings,
              icon: const Icon(Icons.settings, size: 28),
              label: Text(tr('settings')),
            ),
            const SizedBox(height: 10),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: Colors.red.shade700,
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(78),
                textStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              onPressed: _onSosTap,
              icon: const Icon(Icons.sos, size: 34),
              label: Text('${tr('sos')}  •  ${sosTapCount}/3'),
            ),
            const SizedBox(height: 6),
            Text(tr('tripleTap'), textAlign: TextAlign.center),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(66),
                textStyle: const TextStyle(fontSize: 19),
              ),
              onPressed: _openScanner,
              icon: const Icon(Icons.qr_code_scanner, size: 28),
              label: Text(tr('scan')),
            ),
          ],
        ),
      ),
    );
  }
}

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key, required this.tr});
  final String Function(String) tr;

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  String? lastCode;
  bool handled = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.tr('barcodeTitle'))),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(widget.tr('barcodeHelp')),
          ),
          Expanded(
            child: MobileScanner(
              onDetect: (capture) {
                if (handled || capture.barcodes.isEmpty) return;
                final value = capture.barcodes.first.rawValue;
                if (value == null || value.isEmpty) return;
                setState(() {
                  handled = true;
                  lastCode = value;
                });
                showDialog<void>(
                  context: context,
                  builder: (dialogContext) => AlertDialog(
                    title: Text(widget.tr('barcodeRead')),
                    content: SelectableText(
                      '$value\n\n${widget.tr('lookupMissing')}',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.pop(dialogContext);
                          setState(() => handled = false);
                        },
                        child: const Text('OK'),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
